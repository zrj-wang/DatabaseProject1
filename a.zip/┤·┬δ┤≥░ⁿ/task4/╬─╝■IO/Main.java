import java.sql.SQLException;

public class Main {
    public static void main(String[] args) throws SQLException {

        String jdbcURL = "jdbc:postgresql://localhost:5432/postgres";
        String username = "postgres";
        String password = "";
//
        String csvFilePath = "D:/downloadnormal/data/videos1.csv";

    }
}